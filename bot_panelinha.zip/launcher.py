from libs.bot import bot

VERSION = "0.1"

bot.run(VERSION)