CREATE TABLE IF NOT EXISTS Aulas(
    AulaID char(3) PRIMARY KEY,
    AulaLink1 varchar(40),
    AulaLink2 varchar(40)
);