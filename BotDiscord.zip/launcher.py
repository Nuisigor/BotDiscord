from libs.bot import bot

VERSION = "0.3"

bot.run(VERSION)